import 'package:flutterapp/main.dart' as app;
//import 'package:flutter_driver/driver_extension.dart';
void main (){
 //>flutter driver --target=test_driver/test_suites/app.dart enableFlutterDriverExtension();

  app.main();
}