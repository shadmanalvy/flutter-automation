final sendingText = 'Send text 1';
